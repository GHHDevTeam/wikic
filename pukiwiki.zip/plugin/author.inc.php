<?php
// PukiWiki - Yet another WikiWikiWeb clone.
// author.inc.php
// Copyright: 2016 PukiWiki Development Team
// License: GPL v2 or (at your option) any later version
//
// author plugin

function plugin_author_convert() { return ''; }

<?php

namespace dokuwiki\HTTP;

use Exception;

class HTTPClientException extends Exception
{

}
